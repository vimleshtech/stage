﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Net.Mail;

namespace PAF_FileAutomation
{
    public class Emailer
    {
        //Boolean isTestEnvironment = false;
        
        //Treasury Notification
        public void SendMail( string from,string subject,string content)
        {        
            
            //Emailing
            MailMessage message = new MailMessage();
            message.From = new MailAddress("gsd_command_center@uhc.com");
	    message.To = new MailAddress("techvisionitfacebook@gmail.com");	

            message.Subject = subject;

            message.Body = content+" "+from;

            message.IsBodyHtml = true;

            SmtpClient smtp = new SmtpClient("mailo2.uhc.com");       
            smtp.Send(message);
        }

    }
}